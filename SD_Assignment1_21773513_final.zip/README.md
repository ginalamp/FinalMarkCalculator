# README

## Running
```
go build
./ginalamp-mark-tracker
```

## Basic functionality
Calculate real time final mark for overall degree and per module.